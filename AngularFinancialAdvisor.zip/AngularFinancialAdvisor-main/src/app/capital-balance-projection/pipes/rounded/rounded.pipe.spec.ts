import { RoundedPipe } from './rounded.pipe';

describe('RoundedPipe', () => {
  it('create an instance', () => {
    const pipe = new RoundedPipe();
    expect(pipe).toBeTruthy();
  });
});
