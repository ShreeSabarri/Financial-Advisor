export interface ChartDataSetLineItem {
  year: number;
  startBalance: number;
}

export interface ChartData {
  data: number[];
  labels: number[];
}
