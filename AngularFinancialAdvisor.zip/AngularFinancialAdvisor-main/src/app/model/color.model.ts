export interface Color {
  borderColor: string;
  backgroundColor: string;
}
